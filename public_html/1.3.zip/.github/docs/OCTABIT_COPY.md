# OCTABIT_COPY.md

Este documento define os textos oficiais da OctaBit para uso em:

- Landing pages
- Site institucional
- Propostas
- Botões
- Seções de venda

Este arquivo deve ser usado como base para qualquer copywriting.

---

# 1. Headline Principal

Versão principal:

Transforme sua empresa com tecnologia estratégica

---

Versões alternativas:

Estruture, modernize e cresça com tecnologia

ou

Sua empresa pronta para crescer com tecnologia

---

# 2. Subheadline

Versão principal:

A OctaBit estrutura, moderniza e impulsiona pequenas empresas através do método PTE-I.

---

Alternativas:

Organize sua empresa e prepare ela para crescer com previsibilidade.

ou

Tecnologia aplicada de forma estratégica para crescimento empresarial.

---

# 3. Proposta de Valor

Versão principal:

A OctaBit não apenas cria sistemas.

Ela estrutura sua empresa para crescer.

---

Alternativas:

Mais do que tecnologia, entregamos crescimento.

ou

Tecnologia aplicada com foco em resultado.

---

# 4. Sessão de Problema

Headline:

Sua empresa está limitada pela falta de estrutura tecnológica?

Subtexto:

Processos manuais, falta de organização e ausência de sistemas impedem o crescimento.

---

# 5. Sessão de Solução

Headline:

O Método OctaBit resolve isso.

Subtexto:

Através de Presença, Tecnologia, Escala e Inteligência.

---

# 6. Chamada para ação principal (CTA)

Principal:

Agendar diagnóstico gratuito

---

Alternativas:

Falar com especialista

ou

Começar transformação digital

---

# 7. CTA secundários

Ver planos

ou

Conhecer método

ou

Falar com a OctaBit

---

# 8. Texto da sessão de planos

Headline:

Escolha o nível de transformação da sua empresa

Subtexto:

Cada plano representa um estágio de crescimento.

---

# 9. Destaque do plano principal

Texto recomendado:

Plano mais escolhido por empresas em crescimento

---

# 10. Prova de valor

Frases:

Empresas estruturadas crescem com previsibilidade.

ou

A base tecnológica certa permite crescimento sustentável.

---

# 11. Sessão de autoridade

Headline:

Seu parceiro estratégico de crescimento

Subtexto:

A OctaBit acompanha continuamente a evolução da sua empresa.

---

# 12. Sessão final

Headline:

Sua empresa pronta para o próximo nível

Subtexto:

Comece sua transformação digital hoje.

---

# 13. Botões

Nunca usar:

Clique aqui

Sempre usar:

Agendar diagnóstico

ou

Falar com especialista

ou

Começar agora

---

# 14. Linguagem proibida

Nunca usar:

"software house"

Nunca usar:

"criamos sites"

Sempre usar:

Estruturamos empresas

ou

Transformação digital

---

# 15. Regra principal

Sempre comunicar:

Resultado

Nunca comunicar apenas:

Tecnologia

Tecnologia é meio.

Resultado é o objetivo.
