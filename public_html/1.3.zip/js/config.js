// ===== CONFIGURAÇÕES DA OCTABIT - VERSÃO ATUALIZADA =====
const OCTABIT_CONFIG = {
    // Contato
    whatsapp: {
        numero: "5541987762489",
        url: "https://wa.me/5541987762489"
    },
    email: {
        endereco: "octabit@octabit.tech",
        display: "octabit@octabit.tech"
    },

    // Header
    header: {
        logo: "img/logo.svg",
        menu: [
            { texto: "Problema", link: "#problema" },
            { texto: "Como funciona", link: "#como-funciona" },
            { texto: "Método PTE-I", link: "#metodo" },
            { texto: "Planos", link: "#planos" },
            { texto: "Resultados", link: "#autoridade" }
        ],
        cta: "Agendar diagnóstico"
    },

    // HERO
    hero: {
        titulo: "Transformação digital completa para seu negócio crescer",
        subtitulo: "Da identidade visual às automações: aplicamos nossa metodologia PTE-I para estruturar sua presença digital e aumentar seus resultados.",
        botao: "Agendar diagnóstico gratuito →"
    },

    // Seção Problema
    problema: {
        titulo: "Liberte sua equipe do operacional repetitivo",
        subtitulo: "Transforme processos manuais em inteligência de negócio.",
        cards: [
            "Horas perdidas com tarefas repetitivas",
            "Erros manuais que custam caro",
            "Dependência de pessoas, não de processos",
            "Concorrentes mais organizados e rápidos"
        ]
    },

    // Seção Como Funciona
    comoFunciona: {
        titulo: "Como transformamos sua empresa em 3 passos",
        subtitulo: "Um processo testado para tirar sua empresa do papel e colocá-la no próximo nível.",
        passos: [
            {
                icone: "search",
                titulo: "1. Diagnóstico Profundo",
                descricao: "Mapeamos seus processos, dores e objetivos para criar um roteiro personalizado."
            },
            {
                icone: "tool",
                titulo: "2. Implantação Estratégica",
                descricao: "Estruturamos a tecnologia, automatizamos tarefas e organizamos sua operação."
            },
            {
                icone: "bar-chart-2",
                titulo: "3. Acompanhamento Contínuo",
                descricao: "Monitoramos os resultados e ajustamos a rota para garantir o crescimento."
            }
        ]
    },

    // Seção Método PTE-I
    metodo: {
        titulo: "O Método PTE-I resolve isso",
        subtitulo: "Posicionamento, Tecnologia, Engenharia e Inteligência.",
        cards: [
            {
                icone: "eye",
                titulo: "Posicionamento",
                descricao: "Definimos sua identidade visual, mensagem e presença digital para atrair os clientes certos."
            },
            {
                icone: "settings",
                titulo: "Tecnologia",
                descricao: "Implementamos site, sistemas e infraestrutura que fazem seu negócio funcionar."
            },
            {
                icone: "trending-up",
                titulo: "Engenharia",
                descricao: "Automatizamos processos e integramos ferramentas para eliminar tarefas manuais."
            },
            {
                icone: "cpu",
                titulo: "Inteligência",
                descricao: "Entregamos dados, métricas e insights para decisões mais assertivas."
            }
        ],
        botao: "Quero aplicar o método →"
    },

    // Seção Sobre
    sobre: {
        titulo: "A OctaBit existe para estruturar seu crescimento",
        descricao: "Não somos uma software house comum. Não entregamos só código. Entregamos um plano de voo para o seu negócio decolar. Acreditamos que tecnologia, quando bem aplicada, é a maior alavanca de crescimento para pequenas empresas.",
        icone: "users"
    },

    // ===== PLANOS ATUALIZADOS =====
    planos: {
        titulo: "Escolha o plano que estrutura seu crescimento",
        subtitulo: "Cada plano representa um estágio de transformação digital. Comece onde sua empresa precisa.",
        botao: "Quero começar minha transformação →",
        lista: [
            {
                nome: "ESSENCIAL",
                implantacao: 900,
                mensalidade: 597,
                destaque: false,
                beneficios: [
                    "Identidade visual: aplicação ou criação simples",
                    "Site institucional (template OctaBit) com técnicas de SEO",
                    "Google Analytics configurado para captura de dados",
                    "Acompanhamento anual de métricas (leads e conversão)",
                    "Consultoria de tecnologia anual com sugestões de automações",
                    "Suporte para 1 alteração por mês"
                ]
            },
            {
                nome: "PROFISSIONAL",
                implantacao: 1500,
                mensalidade: 1197,
                destaque: true,
                selo: "★ Mais escolhido",
                beneficios: [
                    "Identidade visual: refinamento profissional",
                    "Site personalizado com SEO avançado",
                    "Dashboard com análises de tráfego e conversão",
                    "1 automação de marketing (captura de leads)",
                    "Acompanhamento trimestral de métricas",
                    "Consultoria de tecnologia trimestral",
                    "Até 3 alterações por mês"
                ]
            },
            {
                nome: "EMPRESARIAL",
                implantacao: 3000,
                mensalidade: 2497,
                destaque: false,
                beneficios: [
                    "Identidade visual completa (criação ou reestruturação)",
                    "Automações avançadas de marketing e processos",
                    "Dashboards gerenciais com inteligência de dados em tempo real",
                    "OctaPoint incluso (gestão de equipe e RH básico)",
                    "SEO contínuo e estratégico",
                    "Acompanhamento mensal de métricas e consultoria",
                    "Até 5 horas/mês para melhorias e customizações",
                    "Suporte prioritário"
                ]
            }
        ]
    },

    // Seção Autoridade/Resultados
    autoridade: {
        titulo: "Resultados comprovados",
        subtitulo: "A OctaBit acompanha continuamente a evolução da sua empresa.",
        cards: [
            {
                icone: "bar-chart-2",
                numero: "+40%",
                label: "Crescimento médio",
                descricao: "Empresas que usam nosso método crescem, em média, 40% mais rápido nos primeiros 6 meses."
            },
            {
                icone: "users",
                numero: "100%",
                label: "Clientes ativos",
                descricao: "Taxa de retenção de clientes que continuam conosco após o primeiro ano."
            },
            {
                icone: "clock",
                numero: "24/7",
                label: "Acompanhamento",
                descricao: "Estrutura funcionando 24 horas por dia, 7 dias por semana para seu negócio."
            }
        ],
        case: {
            depoimento: "Antes a gente controlava tudo em planilha e vivia perdido. Hoje consigo ver os serviços, faturamento e clientes em um só lugar. Já economiza um bom tempo no dia a dia.",
            autor: "João Gustavo, KS Oficina"
        }
    },

    // Seção Contato
    contato: {
        titulo: "Pronto para estruturar o crescimento da sua empresa?",
        subtitulo: "Comece sua transformação digital hoje.",
        botao: "Falar com um especialista →"
    },

    // Footer
    footer: {
        copyright: "© 2025 OctaBit. Todos os direitos reservados.",
        texto: "Transformação digital estratégica para pequenas empresas."
    },

    // SEO
    seo: {
        titulo: "OctaBit | Transformação Digital para Negócios Locais",
        descricao: "A OctaBit organiza, moderniza e estrutura sua empresa com sistemas, automação e tecnologia profissional. Tenha controle, previsibilidade e cresça com segurança usando o método PTE-I.",
        keywords: "transformação digital, automação para pequenas empresas, site para negócio local, identidade visual, octapoint, método PTE-I",
        author: "OctaBit"
    }
};