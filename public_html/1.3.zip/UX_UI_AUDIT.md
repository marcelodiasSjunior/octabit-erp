# Auditoria UX/UI – Landing Page OctaBit

Este relatório detalha todos os pontos de melhoria identificados na landing page, com base nos arquivos de contexto, branding, oferta e copy da OctaBit. Cada item inclui descrição, impacto, solução e código sugerido.

---

## 1. Layout e Espaçamento

### Problema: Espaçamento inconsistente entre seções e cards
- **Impacto:** Reduz percepção de valor e profissionalismo.
- **Solução:** Padronizar margens e paddings entre seções e elementos.
- **Código sugerido:**
```css
.container {
  margin-bottom: 60px;
}
.grid {
  gap: 32px;
}
.card, .plan {
  margin-bottom: 0;
}
```

---

## 2. Sobreposições

### Problema: Header pode sobrepor conteúdo em telas pequenas
- **Impacto:** Dificulta navegação, reduz clareza.
- **Solução:** Adicionar padding-top no body ou nas seções principais.
- **Código sugerido:**
```css
body {
  padding-top: 80px;
}
@media (max-width: 768px) {
  body {
    padding-top: 60px;
  }
}
```

---

## 3. Hover States

### Problema: Falta de hover em cards e planos
- **Impacto:** Reduz sensação de interatividade e valor.
- **Solução:** Adicionar hover com leve elevação e sombra.
- **Código sugerido:**
```css
.card:hover, .plan:hover {
  box-shadow: 0 8px 32px rgba(59,130,246,0.10);
  transform: translateY(-4px) scale(1.02);
  border-color: #a855f7;
}
```

---

## 4. Cursor

### Problema: Botões e cards não possuem cursor:pointer
- **Impacto:** Reduz clareza de elementos clicáveis.
- **Solução:** Garantir cursor:pointer em todos botões e elementos interativos.
- **Código sugerido:**
```css
button, .plan button, .menu-toggle, nav a, .whatsapp {
  cursor: pointer;
}
```

---

## 5. Responsividade

### Problema: Possível overflow em grids e planos no mobile
- **Impacto:** Elementos podem ficar cortados ou desalinhados.
- **Solução:** Ajustar grid para 1 coluna no mobile e revisar paddings.
- **Código sugerido:**
```css
@media (max-width: 600px) {
  .grid {
    grid-template-columns: 1fr;
    gap: 20px;
  }
  .container {
    padding: 32px 8px;
  }
}
```

---

## 6. Hierarquia Visual

### Problema: Subtítulos e textos secundários pouco destacados
- **Impacto:** Dificulta escaneabilidade e clareza.
- **Solução:** Usar variações de peso, cor e tamanho para subtítulos.
- **Código sugerido:**
```css
.subheadline, .planos-sub, .metodo-sub, .autoridade-sub, .cta-final {
  color: #a855f7;
  font-size: 1.2rem;
  font-weight: 500;
  margin-bottom: 16px;
}
```

---

## 7. Consistência Visual

### Problema: Bordas e sombras inconsistentes entre cards e planos
- **Impacto:** Reduz percepção premium.
- **Solução:** Padronizar bordas e sombras.
- **Código sugerido:**
```css
.card, .plan {
  border-radius: 14px;
  box-shadow: 0 2px 12px rgba(2,6,23,0.04);
  border: 1px solid #1e293b;
}
```

---

## 8. Percepção de Valor

### Problema: Falta de microdetalhes premium (ex: gradientes, animações suaves)
- **Impacto:** Pode parecer simples demais para público premium.
- **Solução:** Adicionar gradiente sutil em botões e transições suaves.
- **Código sugerido:**
```css
button, .plan button {
  background: linear-gradient(90deg,#3b82f6,#a855f7);
  transition: all 0.25s cubic-bezier(.4,0,.2,1);
}
```

---

## 9. Acessibilidade

### Problema: Contraste insuficiente em alguns textos e botões
- **Impacto:** Dificulta leitura, reduz acessibilidade.
- **Solução:** Garantir contraste mínimo AA (WCAG) em todos textos e botões.
- **Código sugerido:**
```css
body, p, h1, h2, h3, button {
  color: #fff;
}
.plan .price, .price {
  color: #3b82f6;
}
```

---

## 10. Microinterações

### Problema: Falta de feedback visual em botões e cards
- **Impacto:** Reduz sensação de modernidade e resposta.
- **Solução:** Adicionar animação de clique e foco.
- **Código sugerido:**
```css
button:active, .plan button:active {
  transform: scale(0.98);
  filter: brightness(0.95);
}
button:focus, .plan button:focus {
  outline: 2px solid #a855f7;
  outline-offset: 2px;
}
```

---

## Observações Finais

- Recomenda-se revisar todos os textos para garantir clareza e foco em resultado.
- Implemente as sugestões acima para elevar a percepção premium, clareza e conversão da landing page.
- Após ajustes, valide em dispositivos reais e ferramentas de acessibilidade.
