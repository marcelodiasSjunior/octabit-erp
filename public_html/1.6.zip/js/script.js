// ===== RENDERIZADOR BASEADO EM CONFIGURAÇÃO =====

// Aguarda o DOM e também verifica se feather icons carregou
document.addEventListener("DOMContentLoaded", function () {
    console.log("🚀 Iniciando renderização da OctaBit...");

    if (typeof OCTABIT_CONFIG === 'undefined') {
        console.error("❌ ERRO: OCTABIT_CONFIG não encontrado!");
        return;
    }

    // Função para garantir que tudo renderizou
    function renderizarTudo() {
        renderizarHeader();
        renderizarHero();
        renderizarProblema();
        renderizarComoFunciona();
        renderizarMetodo();
        renderizarSobre();
        renderizarPlanos();
        renderizarAutoridade();
        renderizarContato();
        renderizarFooter();

        inicializarEventos();
        inicializarAnimacoes();
        ajustarHeroMobile();
        setupCarrosselIndicator();
        
        // Inicializa feather icons se disponível
        if (typeof feather !== 'undefined') {
            try {
                feather.replace();
            } catch (e) {
                console.warn("Erro ao substituir ícones:", e);
            }
        } else {
            console.warn("Feather Icons não carregou - ícones não serão exibidos");
        }
    }

    // Pequeno delay para garantir que tudo carregou
    setTimeout(renderizarTudo, 100);
});

// ===== FUNÇÕES DE RENDERIZAÇÃO =====

function renderizarHeader() {
    const config = OCTABIT_CONFIG;
    const header = document.getElementById('header-container');
    const email = OCTABIT_CONFIG.email;

    if (!header) return;

    let menuItems = '';
    config.header.menu.forEach(item => {
        menuItems += `<a href="${item.link}">${item.texto}</a>`;
    });

    header.innerHTML = `
        <img src="${config.header.logo}" class="logo" alt="OctaBit" onerror="this.src='https://via.placeholder.com/110x40?text=OctaBit'">
        <div class="menu-toggle" onclick="toggleMenu()" aria-label="Abrir menu">☰</div>
        <nav id="menu">
            ${menuItems}
            <a href="mailto:${email.endereco}" title="Enviar e-mail">
                <i data-feather="mail" width="18" height="18"></i>
            </a>
            <a href="#contato" class="nav-cta" onclick="event.preventDefault(); abrirWhats(); return false;">${config.header.cta}</a>
        </nav>
    `;
}

function renderizarHero() {
    const container = document.getElementById('hero-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.hero;
    container.innerHTML = `
        <h1>${config.titulo}</h1>
        <p>${config.subtitulo}</p>
        <button onclick="abrirWhats()">${config.botao}</button>
    `;
}

function renderizarProblema() {
    const container = document.getElementById('problema-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.problema;
    let cards = '';
    config.cards.forEach(card => {
        cards += `
            <div class="card x-card">
                <span class="x-icon">
                    <i data-feather="x" width="16" height="16"></i>
                </span>
                <span>${card}</span>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="problema-sub">${config.subtitulo}</p>
        <div class="grid">
            ${cards}
        </div>
    `;
}

function renderizarComoFunciona() {
    const container = document.getElementById('como-funciona-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.comoFunciona;
    let passosHTML = '';

    config.passos.forEach(passo => {
        passosHTML += `
            <div class="card">
                <div class="card-icon">
                    <i data-feather="${passo.icone}" width="32" height="32"></i>
                </div>
                <h3>${passo.titulo}</h3>
                <p>${passo.descricao}</p>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="como-funciona-sub">${config.subtitulo}</p>
        <div class="grid grid-3">
            ${passosHTML}
        </div>
    `;
}

function renderizarMetodo() {
    const container = document.getElementById('metodo-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.metodo;
    let cards = '';
    config.cards.forEach(card => {
        cards += `
            <div class="card">
                <div class="card-icon">
                    <i data-feather="${card.icone}" width="32" height="32"></i>
                </div>
                <h3>${card.titulo}</h3>
                <p>${card.descricao}</p>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="metodo-sub">${config.subtitulo}</p>
        <div class="grid">
            ${cards}
        </div>
        <div style="text-align: center; margin-top: 40px;">
            <button onclick="abrirWhats()">${config.botao}</button>
        </div>
    `;
}

function renderizarSobre() {
    const container = document.getElementById('sobre-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.sobre;

    container.innerHTML = `
        <div class="sobre-card">
            <div class="sobre-icon">
                <i data-feather="${config.icone}" width="48" height="48"></i>
            </div>
            <h2>${config.titulo}</h2>
            <p class="sobre-descricao">${config.descricao}</p>
        </div>
    `;
}

function renderizarPlanos() {
    const container = document.getElementById('planos-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.planos;
    let planosHTML = '';

    config.lista.forEach(plano => {
        let beneficiosHTML = '';
        plano.beneficios.slice(0, 4).forEach(b => {
            beneficiosHTML += `<li>${b}</li>`;
        });
        beneficiosHTML += `<li style="color: #a855f7;">+ detalhes no modal...</li>`;

        const destaqueClass = plano.destaque ? 'destaque' : '';
        const seloHTML = plano.destaque ? `<div class="plano-destaque">${plano.selo || '★ Mais escolhido'}</div>` : '';
        const planoId = plano.nome.toLowerCase().normalize("NFD").replace(/[^a-z]/g, '');

        planosHTML += `
            <div class="plan ${destaqueClass}">
                ${seloHTML}
                <h3>${plano.nome}</h3>
                <p class="setup">Setup R$${plano.implantacao}</p>
                <p class="price">R$${plano.mensalidade}<span>/mês</span></p>
                <ul>
                    ${beneficiosHTML}
                </ul>
                <button onclick="abrirModal('${planoId}')">Ver detalhes</button>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="planos-sub">${config.subtitulo}</p>
        <div class="grid">
            ${planosHTML}
        </div>
        <div style="text-align: center; margin-top: 40px;">
            <button onclick="abrirWhats()">${config.botao}</button>
        </div>
    `;
}

function renderizarAutoridade() {
    const container = document.getElementById('autoridade-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.autoridade;
    let cards = '';

    config.cards.forEach(card => {
        cards += `
            <div class="autoridade-card">
                <div class="card-icon" style="margin-bottom: 10px;">
                    <i data-feather="${card.icone}" width="32" height="32"></i>
                </div>
                <div class="autoridade-numero">${card.numero}</div>
                <div class="autoridade-label">${card.label}</div>
                <p class="autoridade-desc">${card.descricao}</p>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="autoridade-sub">${config.subtitulo}</p>
        <div class="grid">
            ${cards}
        </div>
        <div style="margin-top: 40px; text-align: center;">
            <div class="card" style="padding: 30px 20px;">
                <p style="font-size: 1rem; font-style: italic; color: #fff; margin-bottom: 15px;">
                    "${config.case.depoimento}"
                </p>
                <p style="color: #a855f7; font-weight: 600;">${config.case.autor}</p>
            </div>
        </div>
    `;
}

function renderizarContato() {
    const container = document.getElementById('contato-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.contato;
    const email = OCTABIT_CONFIG.email;

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p>${config.subtitulo}</p>
        <button onclick="abrirWhats()" style="margin-bottom: 20px;">${config.botao}</button>
        
        <div style="margin-top: 20px;">
            <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 10px;">ou envie um e-mail</p>
            <a href="mailto:${email.endereco}?subject=Contato%20OctaBit" class="email-link">
                <i data-feather="mail" width="16" height="16"></i>
                ${email.display}
            </a>
        </div>
        
        <p style="color: #475569; font-size: 0.8rem; margin-top: 25px;">
            Respondemos em até 2 horas úteis
        </p>
    `;
}

function renderizarFooter() {
    const container = document.getElementById('footer-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.footer;
    const logo = OCTABIT_CONFIG.header.logo;
    const email = OCTABIT_CONFIG.email;
    const whatsapp = OCTABIT_CONFIG.whatsapp;

    container.innerHTML = `
        <div style="text-align: center; padding: 40px 20px 20px;">
            <img src="${logo}" class="footer-logo" alt="OctaBit">
            
            <div class="footer-contatos">
                <a href="${whatsapp.url}" target="_blank" class="footer-link">
                    <i data-feather="message-circle" width="16" height="16"></i>
                    WhatsApp
                </a>
                <a href="mailto:${email.endereco}" class="footer-link">
                    <i data-feather="mail" width="16" height="16"></i>
                    ${email.display}
                </a>
                <span class="footer-link" style="border: none;">
                    <i data-feather="phone" width="16" height="16"></i>
                    (41) 98776-2489
                </span>
            </div>
            
            <p class="footer-copyright">${config.copyright}</p>
            <p class="footer-texto">${config.texto}</p>
        </div>
    `;
}

// ===== FUNÇÕES DE UTILIDADE =====

function abrirWhats() {
    if (OCTABIT_CONFIG && OCTABIT_CONFIG.whatsapp) {
        window.open(OCTABIT_CONFIG.whatsapp.url, "_blank");
    }
}

function abrirWhatsPlano(plano) {
    if (OCTABIT_CONFIG && OCTABIT_CONFIG.whatsapp) {
        const mensagem = `Olá! Vi o Plano ${plano} da OctaBit e quero agendar um diagnóstico.`;
        const url = `https://wa.me/${OCTABIT_CONFIG.whatsapp.numero}?text=${encodeURIComponent(mensagem)}`;
        window.open(url, '_blank');
    }
}

function toggleMenu() {
    const menu = document.getElementById("menu");
    const toggle = document.querySelector(".menu-toggle");
    if (!menu || !toggle) return;

    menu.classList.toggle("active");
    toggle.textContent = menu.classList.contains("active") ? "✕" : "☰";
}

function inicializarEventos() {
    // Fechar menu ao clicar em link
    const menuLinks = document.querySelectorAll("#menu a");
    menuLinks.forEach(link => {
        link.addEventListener("click", function() {
            const menu = document.getElementById("menu");
            const toggle = document.querySelector(".menu-toggle");
            if (menu) menu.classList.remove("active");
            if (toggle) toggle.textContent = "☰";
        });
    });

    // Scroll suave com fallback
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        link.addEventListener("click", function(e) {
            const href = this.getAttribute("href");
            if (href && href !== "#") {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    const headerHeight = window.innerWidth <= 767 ? 70 : 80;
                    const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

function inicializarAnimacoes() {
    if (!window.IntersectionObserver) {
        // Fallback para navegadores sem suporte
        document.querySelectorAll(".fade").forEach(el => el.classList.add("show"));
        return;
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show");
            }
        });
    }, { threshold: 0.1, rootMargin: "0px 0px -30px 0px" });

    document.querySelectorAll(".fade").forEach(el => observer.observe(el));
}

function ajustarHeroMobile() {
    if (window.innerWidth <= 768) {
        const hero = document.querySelector('.hero');
        if (hero) {
            hero.style.minHeight = (window.innerHeight - 140) + 'px';
        }
    }
}

function setupCarrosselIndicator() {
    const grid = document.querySelector('#planos-container .grid');
    if (!grid) return;
}

// ===== FUNÇÕES DOS MODAIS =====

function abrirModal(plano) {
    const modal = document.getElementById(`modal-${plano}`);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        
        // Atualiza ícones se feather existir
        if (typeof feather !== 'undefined') {
            setTimeout(() => feather.replace(), 50);
        }
    } else {
        abrirWhatsPlano(plano);
    }
}

function fecharModal(plano) {
    const modal = document.getElementById(`modal-${plano}`);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }
}

// Fechar modal ao clicar fora - versão compatível
document.addEventListener('click', function (event) {
    if (event.target && event.target.classList && event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = '';
    }
});

// Fechar com ESC
document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(modal => {
            if (modal.style.display === 'block') {
                modal.style.display = 'none';
                document.body.style.overflow = '';
            }
        });
    }
});

// Touch events com verificação
let touchStartY = 0;
document.addEventListener('touchstart', function(e) {
    if (e.changedTouches && e.changedTouches[0]) {
        touchStartY = e.changedTouches[0].screenY;
    }
});

document.addEventListener('touchend', function(e) {
    const modals = document.querySelectorAll('.modal[style*="display: block"]');
    if (modals.length && e.changedTouches && e.changedTouches[0]) {
        if (e.changedTouches[0].screenY - touchStartY > 60) {
            modals.forEach(modal => {
                modal.style.display = 'none';
                document.body.style.overflow = '';
            });
        }
    }
});

window.addEventListener('load', ajustarHeroMobile);
window.addEventListener('resize', ajustarHeroMobile);