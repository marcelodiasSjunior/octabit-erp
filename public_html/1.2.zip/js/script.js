// ===== RENDERIZADOR BASEADO EM CONFIGURAÇÃO =====

document.addEventListener("DOMContentLoaded", function () {
    console.log("🚀 Iniciando renderização da OctaBit...");

    if (typeof OCTABIT_CONFIG === 'undefined') {
        console.error("❌ ERRO: OCTABIT_CONFIG não encontrado!");
        return;
    }

    renderizarHeader();
    renderizarHero();
    renderizarProblema();
    renderizarComoFunciona(); // <-- NOVO
    renderizarMetodo();
    renderizarSobre();        // <-- NOVO
    renderizarPlanos();
    renderizarAutoridade();
    renderizarContato();
    renderizarFooter();

    // Inicializar Feather Icons APÓS renderizar
    if (typeof feather !== 'undefined') {
        feather.replace();
    }

    inicializarEventos();
    inicializarAnimacoes();

    console.log("✅ Renderização concluída!");
});

// ===== FUNÇÕES DE RENDERIZAÇÃO =====

function renderizarHeader() {
    const config = OCTABIT_CONFIG;
    const header = document.getElementById('header-container');
    const email = OCTABIT_CONFIG.email;

    if (!header) {
        console.warn("Header container não encontrado");
        return;
    }

    let menuItems = '';
    config.header.menu.forEach(item => {
        menuItems += `<a href="${item.link}">${item.texto}</a>`;
    });

    header.innerHTML = `
        <img src="${config.header.logo}" class="logo" alt="OctaBit - Transformação Digital Estratégica">
        <div class="menu-toggle" onclick="toggleMenu()" aria-label="Abrir menu">☰</div>
        <nav id="menu">
            ${menuItems}
            
            <!-- Email com ícone profissional -->
            <a href="mailto:${email.endereco}" style="
                display: inline-flex;
                align-items: center;
                justify-content: center;
                padding: 8px 10px;
            " title="Enviar e-mail">
                <i data-feather="mail" width="18" height="18"></i>
            </a>
            
            <a href="#contato" class="nav-cta" onclick="abrirWhats()">${config.header.cta}</a>
        </nav>
    `;

    if (typeof feather !== 'undefined') {
        feather.replace();
    }
}

function renderizarHero() {
    const container = document.getElementById('hero-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.hero;
    container.innerHTML = `
        <h1>${config.titulo}</h1>
        <p class="subheadline">${config.subtitulo}</p>
        <button onclick="abrirWhats()">${config.botao}</button>
    `;
}

function renderizarProblema() {
    const container = document.getElementById('problema-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.problema;
    let cards = '';
    config.cards.forEach(card => {
        cards += `
            <div class="card x-card">
                <span class="x-icon">
                    <i data-feather="x" width="16" height="16"></i>
                </span>
                <span>${card}</span>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="problema-sub">${config.subtitulo}</p>
        <div class="grid">
            ${cards}
        </div>
    `;
}

function renderizarMetodo() {
    const container = document.getElementById('metodo-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.metodo;
    let cards = '';
    config.cards.forEach(card => {
        cards += `
            <div class="card">
                <div class="card-icon">
                    <i data-feather="${card.icone}" width="32" height="32"></i>
                </div>
                <h3>${card.titulo}</h3>
                <p>${card.descricao}</p>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="metodo-sub">${config.subtitulo}</p>
        <div class="grid">
            ${cards}
        </div>
        <div class="cta-metodo" style="text-align: center; margin-top: 50px;">
            <button onclick="abrirWhats()">${config.botao}</button>
        </div>
    `;
}

function renderizarPlanos() {
    const container = document.getElementById('planos-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.planos;
    let planosHTML = '';

    config.lista.forEach(plano => {
        let beneficiosHTML = '';
        plano.beneficios.forEach(b => {
            beneficiosHTML += `<li>${b}</li>`;
        });

        const destaqueClass = plano.destaque ? 'destaque' : '';
        const seloHTML = plano.destaque ? `<div class="plano-destaque">${plano.selo}</div>` : '';
        const planoId = plano.nome.toLowerCase().normalize("NFD").replace(/[^a-z]/g, '');

        planosHTML += `
            <div class="plan ${destaqueClass}">
                ${seloHTML}
                <h3>${plano.nome}</h3>
                <p class="setup">Implantação R$${plano.implantacao}</p>
                <p class="price">R$${plano.mensalidade}<span>/mês</span></p>
                <ul>
                    ${beneficiosHTML}
                </ul>
                <button onclick="abrirModal('${planoId}')">Ver detalhes do plano</button>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="planos-sub">${config.subtitulo}</p>
        <div class="grid">
            ${planosHTML}
        </div>
        <div class="cta-planos" style="text-align: center; margin-top: 50px;">
            <button onclick="abrirWhats()">${config.botao}</button>
        </div>
    `;
}

function renderizarAutoridade() {
    const container = document.getElementById('autoridade-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.autoridade;
    let cards = '';

    config.cards.forEach(card => {
        cards += `
            <div class="autoridade-card">
                <div class="card-icon" style="margin-bottom: 15px;">
                    <i data-feather="${card.icone}" width="40" height="40" style="color: #a855f7;"></i>
                </div>
                <div class="autoridade-numero">${card.numero}</div>
                <div class="autoridade-label">${card.label}</div>
                <p class="autoridade-desc">${card.descricao}</p>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="autoridade-sub">${config.subtitulo}</p>
        <div class="grid">
            ${cards}
        </div>
        <div style="margin-top: 60px; text-align: center;">
            <div class="card" style="max-width: 600px; margin: 0 auto; padding: 40px;">
                <p style="font-size: 1.2rem; font-style: italic; color: #fff; margin-bottom: 20px;">
                    ${config.case.depoimento}
                </p>
                <p style="color: #a855f7; font-weight: 600;">${config.case.autor}</p>
            </div>
        </div>
    `;
}

function renderizarContato() {
    const container = document.getElementById('contato-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.contato;
    const email = OCTABIT_CONFIG.email;

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="cta-final">${config.subtitulo}</p>
        
        <!-- Botão principal -->
        <button onclick="abrirWhats()" style="margin-bottom: 20px;">
            ${config.botao}
        </button>
        
        <!-- Opção de email elegante -->
        <div style="margin-top: 25px;">
            <p style="color: #64748b; font-size: 0.95rem; margin-bottom: 15px;">
                ou se preferir, envie um e-mail
            </p>
            <a href="mailto:${email.endereco}?subject=Contato%20OctaBit&body=Olá,%20gostaria%20de%20saber%20mais%20sobre%20o%20método%20PTE-I..." 
               style="
                    color: #a855f7;
                    text-decoration: none;
                    font-size: 1.1rem;
                    font-weight: 500;
                    padding: 10px 24px;
                    border: 1px solid #1e293b;
                    border-radius: 50px;
                    display: inline-flex;
                    align-items: center;
                    gap: 10px;
                    transition: all 0.3s ease;
                    background: rgba(168, 85, 247, 0.02);
               "
               onmouseover="this.style.background='rgba(168,85,247,0.1)'; this.style.borderColor='#a855f7'"
               onmouseout="this.style.background='rgba(168,85,247,0.02)'; this.style.borderColor='#1e293b'">
                <i data-feather="mail" width="18" height="18"></i>
                ${email.display}
            </a>
        </div>
        
        <p style="color: #475569; font-size: 0.85rem; margin-top: 30px;">
            Respondemos em até 2 horas úteis
        </p>
    `;
}

function renderizarFooter() {
    const container = document.getElementById('footer-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.footer;
    const logo = OCTABIT_CONFIG.header.logo;
    const email = OCTABIT_CONFIG.email;
    const whatsapp = OCTABIT_CONFIG.whatsapp;

    container.innerHTML = `
        <div style="text-align: center; padding: 60px 20px 40px; border-top: 1px solid #1e293b;">
            
            <!-- Logo -->
            <img src="${logo}" style="width: 50px; opacity: 0.8; margin-bottom: 30px;" alt="OctaBit">
            
            <!-- Contatos no Footer -->
            <div style="display: flex; gap: 30px; justify-content: center; flex-wrap: wrap; margin-bottom: 35px;">
                
                <!-- WhatsApp -->
                <a href="${whatsapp.url}" target="_blank" 
                   style="
                        color: #94a3b8;
                        text-decoration: none;
                        display: inline-flex;
                        align-items: center;
                        gap: 8px;
                        padding: 8px 16px;
                        border-radius: 8px;
                        transition: all 0.3s ease;
                        font-size: 0.95rem;
                   "
                   onmouseover="this.style.color='#fff'; this.style.background='rgba(37,211,102,0.1)'"
                   onmouseout="this.style.color='#94a3b8'; this.style.background='transparent'">
                    <i data-feather="message-circle" width="16" height="16"></i>
                    WhatsApp
                </a>
                
                <!-- Email -->
                <a href="mailto:${email.endereco}" 
                   style="
                        color: #94a3b8;
                        text-decoration: none;
                        display: inline-flex;
                        align-items: center;
                        gap: 8px;
                        padding: 8px 16px;
                        border-radius: 8px;
                        transition: all 0.3s ease;
                        font-size: 0.95rem;
                   "
                   onmouseover="this.style.color='#fff'; this.style.background='rgba(168,85,247,0.1)'"
                   onmouseout="this.style.color='#94a3b8'; this.style.background='transparent'">
                    <i data-feather="mail" width="16" height="16"></i>
                    ${email.display}
                </a>
                
                <!-- Telefone -->
                <span style="color: #475569; display: inline-flex; align-items: center; gap: 8px; font-size: 0.95rem;">
                    <i data-feather="phone" width="16" height="16"></i>
                    (41) 98776-2489
                </span>
            </div>
            
            <!-- Textos legais -->
            <p style="color: #475569; margin-bottom: 5px; font-size: 0.9rem;">${config.copyright}</p>
            <p style="color: #334155; font-size: 0.8rem;">${config.texto}</p>
        </div>
    `;
}

// ===== FUNÇÕES DE UTILIDADE =====

function abrirWhats() {
    window.open(OCTABIT_CONFIG.whatsapp.url, "_blank");
}

function toggleMenu() {
    const menu = document.getElementById("menu");
    if (!menu) return;

    menu.classList.toggle("active");

    const menuToggle = document.querySelector(".menu-toggle");
    if (menuToggle) {
        menuToggle.textContent = menu.classList.contains("active") ? "✕" : "☰";
    }
}

function inicializarEventos() {
    // Fechar menu ao clicar em link
    const menuLinks = document.querySelectorAll("#menu a");
    const menu = document.getElementById("menu");

    menuLinks.forEach(link => {
        link.addEventListener("click", () => {
            if (menu) {
                menu.classList.remove("active");
                const menuToggle = document.querySelector(".menu-toggle");
                if (menuToggle) menuToggle.textContent = "☰";
            }
        });
    });

    // Fechar menu ao clicar fora
    document.addEventListener("click", function (event) {
        const menu = document.getElementById("menu");
        const menuToggle = document.querySelector(".menu-toggle");

        if (menu && menuToggle) {
            if (menu.classList.contains("active") &&
                !menu.contains(event.target) &&
                !menuToggle.contains(event.target)) {
                menu.classList.remove("active");
                menuToggle.textContent = "☰";
            }
        }
    });

    // Scroll suave para links âncora
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(link => {
        link.addEventListener("click", function (e) {
            const href = this.getAttribute("href");
            if (href && href !== "#") {
                e.preventDefault();
                const targetElement = document.querySelector(href);
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    });
                }
            }
        });
    });
}

function inicializarAnimacoes() {
    const elements = document.querySelectorAll(".fade");

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show");
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    });

    elements.forEach(el => observer.observe(el));
}

// Detecção mobile
function isMobile() {
    return window.innerWidth <= 768;
}

function ajustarHeroMobile() {
    if (isMobile()) {
        const hero = document.querySelector('.hero');
        if (hero) {
            hero.style.minHeight = window.innerHeight - 70 + 'px';
        }
    }
}
// ===== NOVAS FUNÇÕES DE RENDERIZAÇÃO =====

function renderizarComoFunciona() {
    const container = document.getElementById('como-funciona-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.comoFunciona;
    let passosHTML = '';

    config.passos.forEach(passo => {
        passosHTML += `
            <div class="card">
                <div class="card-icon">
                    <i data-feather="${passo.icone}" width="32" height="32"></i>
                </div>
                <h3>${passo.titulo}</h3>
                <p>${passo.descricao}</p>
            </div>
        `;
    });

    container.innerHTML = `
        <h2>${config.titulo}</h2>
        <p class="como-funciona-sub">${config.subtitulo}</p>
        <div class="grid grid-3">
            ${passosHTML}
        </div>
    `;
}

function renderizarSobre() {
    const container = document.getElementById('sobre-container');
    if (!container) return;

    const config = OCTABIT_CONFIG.sobre;

    container.innerHTML = `
        <div class="sobre-card">
            <div class="sobre-icon">
                <i data-feather="${config.icone}" width="48" height="48"></i>
            </div>
            <h2>${config.titulo}</h2>
            <p class="sobre-descricao">${config.descricao}</p>
        </div>
    `;
}

// ===== FUNÇÕES DOS MODAIS =====

function abrirModal(plano) {
    console.log("Tentando abrir modal:", plano); // Para debug

    // Mapeia o nome do plano para o ID correto
    const mapaPlanos = {
        'essencial': 'essencial',
        'profissional': 'profissional',
        'empresarial': 'empresarial'
    };

    const modalId = mapaPlanos[plano] || plano;
    const modal = document.getElementById(`modal-${modalId}`);

    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden'; // Trava rolagem

        // Atualizar Feather Icons dentro do modal
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
        console.log("Modal aberto com sucesso!");
    } else {
        console.error(`ERRO: Modal modal-${modalId} não encontrado no DOM`);
        // Fallback: se não encontrar o modal, vai direto pro WhatsApp
        abrirWhatsPlano(plano);
    }
}

function fecharModal(plano) {
    console.log("Fechando modal:", plano);
    const modal = document.getElementById(`modal-${plano}`);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = ''; // Libera rolagem
    }
}

function abrirWhatsPlano(plano) {
    const mensagem = `Olá! Vi o Plano ${plano} da OctaBit e quero agendar um diagnóstico para entender como ele se aplica ao meu negócio.`;
    const url = `https://wa.me/${OCTABIT_CONFIG.whatsapp.numero}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
}

// Fechar modal ao clicar fora (versão melhorada)
document.addEventListener('click', function (event) {
    if (event.target.classList.contains('modal')) {
        console.log("Fechando modal por clique fora");
        event.target.style.display = 'none';
        document.body.style.overflow = '';
    }
});

// Fechar com tecla ESC
document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
        console.log("Fechando modal por tecla ESC");
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (modal.style.display === 'block') {
                modal.style.display = 'none';
                document.body.style.overflow = '';
            }
        });
    }
});
// ===== SWIPE DOWN PARA FECHAR MODAL NO MOBILE =====
let touchStartY = 0;
let touchEndY = 0;

document.addEventListener('touchstart', function (event) {
    // Só captura se tiver um modal aberto
    const modalsAbertos = document.querySelectorAll('.modal[style*="display: block"]');
    if (modalsAbertos.length > 0) {
        touchStartY = event.changedTouches[0].screenY;
    }
}, { passive: true });

document.addEventListener('touchend', function (event) {
    // Só processa se tiver um modal aberto
    const modalsAbertos = document.querySelectorAll('.modal[style*="display: block"]');
    if (modalsAbertos.length > 0) {
        touchEndY = event.changedTouches[0].screenY;

        // Se o usuário deslizou para baixo mais de 80px (gesto de swipe down)
        if (touchEndY - touchStartY > 80) {
            console.log("👆 Swipe down detectado, fechando modal");

            modalsAbertos.forEach(modal => {
                modal.style.display = 'none';
                document.body.style.overflow = '';
            });
        }
    }
});
window.addEventListener('load', ajustarHeroMobile);
window.addEventListener('resize', ajustarHeroMobile);