// ===== CONFIGURAÇÕES DA OCTABIT - VERSÃO OTIMIZADA PARA CONVERSÃO =====
const OCTABIT_CONFIG = {
    // Contato
    whatsapp: {
        numero: "5541987762489",
        url: "https://wa.me/5541987762489"
    },
    email: {
        endereco: "octabit@octabit.tech",
        display: "octabit@octabit.tech"
    },

    // Header
    header: {
        logo: "img/logo.svg",
        menu: [
            { texto: "Problema", link: "#problema" },
            { texto: "Como funciona", link: "#como-funciona" },
            { texto: "Método", link: "#metodo" },
            { texto: "Planos", link: "#planos" },
            { texto: "Resultados", link: "#autoridade" }
        ],
        cta: "Agendar diagnóstico"
    },

    // ===== HERO REFORÇADO =====
    hero: {
        titulo: "Transforme sua empresa em uma máquina de crescimento com tecnologia",
        subtitulo: "Estruturamos sua operação para você crescer com previsibilidade, usando o método PTE-I.",
        botao: "Agendar diagnóstico gratuito →"
    },

    // Seção Problema
    problema: {
        titulo: "Liberte sua equipe do operacional repetitivo",
        subtitulo: "Transforme processos manuais em inteligência de negócio.",
        cards: [
            "Horas perdidas com tarefas repetitivas",
            "Erros manuais que custam caro",
            "Dependência de pessoas, não de processos",
            "Concorrentes mais organizados e rápidos"
        ]
    },

    // ===== NOVA SEÇÃO: COMO FUNCIONA =====
    comoFunciona: {
        titulo: "Como transformamos sua empresa em 3 passos",
        subtitulo: "Um processo testado para tirar sua empresa do papel e colocá-la no próximo nível.",
        passos: [
            {
                icone: "search",
                titulo: "1. Diagnóstico Profundo",
                descricao: "Mapeamos seus processos, dores e objetivos para criar um roteiro personalizado."
            },
            {
                icone: "tool",
                titulo: "2. Implantação Estratégica",
                descricao: "Estruturamos a tecnologia, automatizamos tarefas e organizamos sua operação."
            },
            {
                icone: "bar-chart-2",
                titulo: "3. Acompanhamento Contínuo",
                descricao: "Monitoramos os resultados e ajustamos a rota para garantir o crescimento."
            }
        ]
    },

    // Seção Método PTE-I
    metodo: {
        titulo: "O Método PTE-I resolve isso",
        subtitulo: "Através de Presença, Tecnologia, Escala e Inteligência.",
        cards: [
            {
                icone: "eye",
                titulo: "Presença",
                descricao: "Posicione-se como autoridade e seja encontrado pelos seus clientes."
            },
            {
                icone: "settings",
                titulo: "Tecnologia",
                descricao: "Automatize tarefas repetitivas e organize toda a sua operação."
            },
            {
                icone: "trending-up",
                titulo: "Escala",
                descricao: "Crie uma estrutura preparada para crescer sem travar."
            },
            {
                icone: "cpu",
                titulo: "Inteligência",
                descricao: "Tome decisões baseadas em dados, não em achismos."
            }
        ],
        botao: "Quero aplicar o método →"
    },

    // ===== NOVA SEÇÃO: SOBRE A OCTABIT =====
    sobre: {
        titulo: "A OctaBit existe para estruturar seu crescimento",
        descricao: "Não somos uma software house comum. Não entregamos só código. Entregamos um plano de voo para o seu negócio decolar. Acreditamos que tecnologia, quando bem aplicada, é a maior alavanca de crescimento para pequenas empresas.",
        icone: "users"
    },

    // ===== PLANOS REFORÇADOS (Foco em Resultado) =====
    planos: {
        titulo: "Escolha o plano que estrutura seu crescimento",
        subtitulo: "Cada plano representa um estágio de transformação. Comece onde sua empresa precisa.",
        botao: "Quero começar minha transformação →",
        lista: [
            {
                nome: "Essencial",
                implantacao: 600,
                mensalidade: 497,
                destaque: false,
                beneficios: [
                    "Site profissional que atrai clientes (template OctaBit)",
                    "Configuração completa da estrutura digital",
                    "Suporte técnico para não parar",
                    "Relatório trimestral de desempenho",
                    "Fundação digital para começar a crescer"
                ]
            },
            {
                nome: "Profissional",
                implantacao: 1200,
                mensalidade: 997,
                destaque: true,
                selo: "★ Mais escolhido por empresas em crescimento",
                beneficios: [
                    "Site personalizado que vende sua marca",
                    "Melhorias contínuas baseadas em dados",
                    "Dashboard que mostra de onde vêm seus clientes",
                    "Relatórios mensais para decisões rápidas",
                    "Consultoria estratégica para acelerar resultados",
                    "Estrutura escalável pronta para crescer"
                ]
            },
            {
                nome: "Empresarial",
                implantacao: 2500,
                mensalidade: 1997,
                destaque: false,
                beneficios: [
                    "Sistemas personalizados que resolvem seus problemas",
                    "Automação de processos para eliminar tarefas manuais",
                    "Dashboard avançado com previsões de crescimento",
                    "Relatórios completos para sócios e investidores",
                    "Acompanhamento estratégico contínuo (conselheiro)"
                ]
            }
        ]
    },

    // Seção Autoridade/Resultados (sem alterações)
    autoridade: {
        titulo: "Resultados comprovados",
        subtitulo: "A OctaBit acompanha continuamente a evolução da sua empresa.",
        cards: [
            {
                icone: "bar-chart-2",
                numero: "+40%",
                label: "Crescimento médio",
                descricao: "Empresas que usam nosso método crescem, em média, 40% mais rápido nos primeiros 6 meses."
            },
            {
                icone: "users",
                numero: "100%",
                label: "Clientes ativos",
                descricao: "Taxa de retenção de clientes que continuam conosco após o primeiro ano."
            },
            {
                icone: "clock",
                numero: "24/7",
                label: "Acompanhamento",
                descricao: "Estrutura funcionando 24 horas por dia, 7 dias por semana para seu negócio."
            }
        ],
        case: {
            depoimento: "Antes a gente controlava tudo em planilha e vivia perdido. Hoje consigo ver os serviços, faturamento e clientes em um só lugar. Já economiza um bom tempo no dia a dia.",
            autor: "João Gustavo, KS Oficina"
        }
    },

    // Seção CTA Final
    contato: {
        titulo: "Pronto para estruturar o crescimento da sua empresa?",
        subtitulo: "Comece sua transformação digital hoje.",
        botao: "Falar com um especialista →"
    },

    // Footer
    footer: {
        copyright: "© 2024 OctaBit. Todos os direitos reservados.",
        texto: "Transformação digital estratégica para pequenas empresas."
    },

    // SEO
    seo: {
        titulo: "OctaBit | Sistemas, Automação e Estrutura Digital para Empresas",
        descricao: "A OctaBit organiza, moderniza e estrutura sua empresa com sistemas, automação e tecnologia profissional. Tenha controle, previsibilidade e cresça com segurança usando o método PTE-I.",
        keywords: "sistemas para empresas, automação empresarial, software para empresas, site profissional, tecnologia empresarial, organização empresarial, OctaBit, método PTE-I, estrutura digital",
        author: "OctaBit"
    }
};